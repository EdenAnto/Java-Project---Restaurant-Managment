/**
 
* Matan Levy– 318262383

* Eden Anto– 318459518

* Gil Mantzur– 313373151

* Omer Inbar- 318520608 

**/




public class Main {

	public static void main(String[] args)  {

		mmg manager = new mmg();
		manager.startProgram();
		
	}
	


}


